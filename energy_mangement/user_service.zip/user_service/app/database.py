from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
from dotenv import load_dotenv

# Încarcă variabilele de mediu (de ex. din docker-compose.yml)
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

if DATABASE_URL is None:
    print("Atenție: Variabila de mediu DATABASE_URL nu este setată.")
    # Setează o valoare default pentru a rula local, dacă dorești
    # DATABASE_URL = "postgresql://user:password@localhost/energy_db"

engine = create_engine(DATABASE_URL)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

# Dependință FastAPI pentru a obține o sesiune de bază de date
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()